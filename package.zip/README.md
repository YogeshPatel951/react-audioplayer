# ReactJS Audio Player (Spotify Player clone)

  

Custom Javascript Audio Player with ReactJS and SCSS
## Demo
[https://react-audioplayer.herokuapp.com/](https://react-audioplayer.herokuapp.com/)

## Usage  

``` bash
# install dependencies
$ npm install
# serve with hot reload at localhost:3000
$ npm start
# serve with hot reload and Sass watch at localhost:3000
$ npm run dev
# production build
$ npm run build

```

