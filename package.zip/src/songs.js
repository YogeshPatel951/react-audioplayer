export default [
    {
        artistname: "Dee Yan-Key",
        image: "/images/butterflies.jpg",
        title: "Butterflies",
        src: "/audio/Butterflies.mp3"
    },
    {
        artistname: "Jahzzar",
        image: "/images/siesta.jpg",
        title: "Siesta",
        src: "/audio/Siesta.mp3"
    },
    {
        artistname: "DASK",
        image: "/images/pure.jpg",
        title: "Pure",
        src: "/audio/Pure.mp3"
    }
]